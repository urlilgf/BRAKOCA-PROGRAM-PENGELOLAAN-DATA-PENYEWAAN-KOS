#include <iostream>
#include <iomanip>
#include "dataPenyewa.hpp"

using namespace std;

int main() {
    Penyewa daftarPenyewa[MAX_PENYEWA];
    int jumlahData = 0;
    int pilihan;

    do {
        tampilkanMenu();
        cout << "Pilih menu (1-5): ";
        if (!(cin >> pilihan)) {
            cout << "Input tidak valid! Harap masukkan angka.\n";
            cin.clear();
            cin.ignore(10000, '\n');
            continue;
        }

        switch (pilihan) {
            case 1:
                tambahData(daftarPenyewa, jumlahData);
                break;
            case 2:
                tampilkanData(daftarPenyewa, jumlahData);
                break;
            case 3:
                cariData(daftarPenyewa, jumlahData);
                break;
            case 4:
                prosesPembayaran(daftarPenyewa, jumlahData);
                break;
            case 5:
                cout << "Keluar dari program. Terima kasih!\n";
                break;
            default:
                cout << "Pilihan tidak valid! Silakan pilih menu 1-5.\n";
        }
        cout << "\n----------------------------------------\n";
    } while (pilihan != 5);

    return 0;
}

void tampilkanMenu() {
    cout << "\n========================================\n";
    cout << "   PROGRAM PENGELOLAAN DATA PENYEWAAN KOS\n";
    cout << "========================================\n";
    cout << "1. Tambah Data\n";
    cout << "2. Tampilkan Data\n";
    cout << "3. Cari Data\n";
    cout << "4. Pembayaran\n";
    cout << "5. Keluar\n";
}

void tambahData(Penyewa daftarPenyewa[], int &jumlahData) {
    cout << "\n--- TAMBAH / UPDATE DATA PENYEWA ---\n";
    string namaInput;
    cout << "Masukkan nama penyewa: ";
    cin.ignore();
    getline(cin, namaInput);

    int indeksDitemukan = -1;
    for (int i = 0; i < jumlahData; i++) {
        if (daftarPenyewa[i].nama == namaInput) {
            indeksDitemukan = i;
            break;
        }
    }

    if (indeksDitemukan != -1) {
        cout << "Penyewa dengan nama \"" << namaInput << "\" sudah terdaftar. Data akan diperbarui.\n";

        int noKamar;
        while (true) {
            cout << "Masukkan nomor kamar baru (1 - 20): ";
            if (cin >> noKamar && noKamar >= 1 && noKamar <= 20) {
                bool kamarTerpakai = false;
                for (int i = 0; i < jumlahData; i++) {
                    if (i != indeksDitemukan && daftarPenyewa[i].nomorKamar == noKamar) {
                        kamarTerpakai = true;
                        break;
                    }
                }
                if (kamarTerpakai) {
                    cout << "Kamar nomor " << noKamar << " sudah terisi oleh penyewa lain!\n";
                } else {
                    daftarPenyewa[indeksDitemukan].nomorKamar = noKamar;
                    break;
                }
            } else {
                cout << "Nomor kamar tidak valid! Harus antara 1 sampai 20.\n";
                cin.clear();
                cin.ignore(10000, '\n');
            }
        }

        cout << "Masukkan harga sewa: ";
        cin >> daftarPenyewa[indeksDitemukan].hargaSewa;

        cout << "Masukkan total pembayaran: ";
        cin >> daftarPenyewa[indeksDitemukan].pembayaran;

        if (daftarPenyewa[indeksDitemukan].pembayaran == daftarPenyewa[indeksDitemukan].hargaSewa) {
            daftarPenyewa[indeksDitemukan].status = "LUNAS";
            cout << "Status: LUNAS\n";
        } else if (daftarPenyewa[indeksDitemukan].pembayaran < daftarPenyewa[indeksDitemukan].hargaSewa) {
            daftarPenyewa[indeksDitemukan].status = "BELUM LUNAS";
            double kekurangan = daftarPenyewa[indeksDitemukan].hargaSewa - daftarPenyewa[indeksDitemukan].pembayaran;
            cout << "Pembayaran tidak valid! (Kurang Rp " << fixed << setprecision(2) << kekurangan << ")\n";
            cout << "Status: BELUM LUNAS\n";
        } else {
            daftarPenyewa[indeksDitemukan].status = "BELUM LUNAS";
            double kelebihan = daftarPenyewa[indeksDitemukan].pembayaran - daftarPenyewa[indeksDitemukan].hargaSewa;
            cout << "Pembayaran tidak valid! (Kelebihan Rp " << fixed << setprecision(2) << kelebihan << ")\n";
            cout << "Status: BELUM LUNAS (Harus pas)\n";
        }

        cout << "Data penyewa berhasil diperbarui!\n";
        return;
    }

    if (jumlahData >= MAX_PENYEWA) {
        cout << "Kapasitas kamar sudah penuh (Maksimal 20 kamar)!\n";
        return;
    }

    daftarPenyewa[jumlahData].nama = namaInput;

    int noKamar;
    while (true) {
        cout << "Masukkan nomor kamar (1 - 20): ";
        if (cin >> noKamar && noKamar >= 1 && noKamar <= 20) {
            bool kamarTerpakai = false;
            for (int i = 0; i < jumlahData; i++) {
                if (daftarPenyewa[i].nomorKamar == noKamar) {
                    kamarTerpakai = true;
                    break;
                }
            }
            if (kamarTerpakai) {
                cout << "Kamar nomor " << noKamar << " sudah terisi! Pilih nomor lain.\n";
            } else {
                daftarPenyewa[jumlahData].nomorKamar = noKamar;
                break;
            }
        } else {
            cout << "Nomor kamar tidak valid! Harus antara 1 sampai 20.\n";
            cin.clear();
            cin.ignore(10000, '\n');
        }
    }

    cout << "Masukkan harga sewa: ";
    cin >> daftarPenyewa[jumlahData].hargaSewa;

    cout << "Masukkan pembayaran awal: ";
    cin >> daftarPenyewa[jumlahData].pembayaran;

    if (daftarPenyewa[jumlahData].pembayaran == daftarPenyewa[jumlahData].hargaSewa) {
        daftarPenyewa[jumlahData].status = "LUNAS";
        cout << "Status: LUNAS\n";
    } else if (daftarPenyewa[jumlahData].pembayaran < daftarPenyewa[jumlahData].hargaSewa) {
        daftarPenyewa[jumlahData].status = "BELUM LUNAS";
        double kekurangan = daftarPenyewa[jumlahData].hargaSewa - daftarPenyewa[jumlahData].pembayaran;
        cout << "Pembayaran tidak valid! (Kurang Rp " << fixed << setprecision(2) << kekurangan << ")\n";
        cout << "Status: BELUM LUNAS\n";
    } else {
        daftarPenyewa[jumlahData].status = "BELUM LUNAS";
        double kelebihan = daftarPenyewa[jumlahData].pembayaran - daftarPenyewa[jumlahData].hargaSewa;
        cout << "Pembayaran tidak valid! (Kelebihan Rp " << fixed << setprecision(2) << kelebihan << ")\n";
        cout << "Status: BELUM LUNAS (Harus pas)\n";
    }

    jumlahData++;
    cout << "Data berhasil ditambahkan!\n";
}

void tampilkanData(Penyewa daftarPenyewa[], int jumlahData) {
    if (jumlahData == 0) {
        cout << "Belum ada data penyewa.\n";
        return;
    }

    cout << "\n--- DAFTAR PENYEWA KOS (Kamar 1-20) ---\n";
    for (int i = 0; i < jumlahData; i++) {
        cout << "Data ke-" << i + 1 << "\n";
        cout << "Nama          : " << daftarPenyewa[i].nama << "\n";
        cout << "Nomor Kamar   : " << daftarPenyewa[i].nomorKamar << "\n";
        cout << "Harga Sewa    : Rp " << fixed << setprecision(2) << daftarPenyewa[i].hargaSewa << "\n";
        cout << "Total Dibayar : Rp " << fixed << setprecision(2) << daftarPenyewa[i].pembayaran << "\n";
        cout << "Status        : " << daftarPenyewa[i].status << "\n";
        
        if (daftarPenyewa[i].pembayaran < daftarPenyewa[i].hargaSewa) {
            double kekurangan = daftarPenyewa[i].hargaSewa - daftarPenyewa[i].pembayaran;
            cout << "Keterangan    : Pembayaran tidak valid (Kurang Rp " << fixed << setprecision(2) << kekurangan << ")\n";
        } else if (daftarPenyewa[i].pembayaran > daftarPenyewa[i].hargaSewa) {
            double kelebihan = daftarPenyewa[i].pembayaran - daftarPenyewa[i].hargaSewa;
            cout << "Keterangan    : Pembayaran tidak valid (Kelebihan Rp " << fixed << setprecision(2) << kelebihan << ")\n";
        }
        cout << "----------------------------------------\n";
    }
}

void cariData(Penyewa daftarPenyewa[], int jumlahData) {
    if (jumlahData == 0) {
        cout << "Belum ada data penyewa untuk dicari.\n";
        return;
    }

    string keyword;
    cout << "\n--- CARI DATA PENYEWA ---\n";
    cout << "Masukkan nama penyewa yang dicari: ";
    cin.ignore();
    getline(cin, keyword);

    bool ditemukan = false;
    for (int i = 0; i < jumlahData; i++) {
        if (daftarPenyewa[i].nama == keyword) {
            cout << "\nData Ditemukan!\n";
            cout << "Nama          : " << daftarPenyewa[i].nama << "\n";
            cout << "Nomor Kamar   : " << daftarPenyewa[i].nomorKamar << "\n";
            cout << "Harga Sewa    : Rp " << fixed << setprecision(2) << daftarPenyewa[i].hargaSewa << "\n";
            cout << "Total Dibayar : Rp " << fixed << setprecision(2) << daftarPenyewa[i].pembayaran << "\n";
            cout << "Status        : " << daftarPenyewa[i].status << "\n";
            
            if (daftarPenyewa[i].pembayaran < daftarPenyewa[i].hargaSewa) {
                double kekurangan = daftarPenyewa[i].hargaSewa - daftarPenyewa[i].pembayaran;
                cout << "Keterangan    : Pembayaran tidak valid (Kurang Rp " << fixed << setprecision(2) << kekurangan << ")\n";
            } else if (daftarPenyewa[i].pembayaran > daftarPenyewa[i].hargaSewa) {
                double kelebihan = daftarPenyewa[i].pembayaran - daftarPenyewa[i].hargaSewa;
                cout << "Keterangan    : Pembayaran tidak valid (Kelebihan Rp " << fixed << setprecision(2) << kelebihan << ")\n";
            }
            ditemukan = true;
            break;
        }
    }

    if (!ditemukan) {
        cout << "Data penyewa dengan nama \"" << keyword << "\" tidak ditemukan.\n";
    }
}

void prosesPembayaran(Penyewa daftarPenyewa[], int jumlahData) {
    if (jumlahData == 0) {
        cout << "Belum ada data penyewa.\n";
        return;
    }

    string keyword;
    cout << "\n--- MENU PEMBAYARAN ---\n";
    cout << "Masukkan nama penyewa: ";
    cin.ignore();
    getline(cin, keyword);

    bool ditemukan = false;
    for (int i = 0; i < jumlahData; i++) {
        if (daftarPenyewa[i].nama == keyword) {
            ditemukan = true;
            cout << "Penyewa ditemukan. Kamar: " << daftarPenyewa[i].nomorKamar << "\n";
            cout << "Harga Sewa per Periode     : Rp " << fixed << setprecision(2) << daftarPenyewa[i].hargaSewa << "\n";
            cout << "Status Saat Ini            : " << daftarPenyewa[i].status << "\n";

            // Jika status sebelumnya sudah LUNAS, input berikutnya adalah pembayaran periode baru
            if (daftarPenyewa[i].status == "LUNAS") {
                cout << "\n[INFO] Pembayaran sebelumnya sudah LUNAS. Silakan masukkan pembayaran untuk periode baru.\n";
                cout << "Masukkan jumlah pembayaran baru: ";
                
                double pembayaranBaru;
                if (!(cin >> pembayaranBaru) || pembayaranBaru < 0) {
                    cout << "Input pembayaran tidak valid atau bernilai minus!\n";
                    break;
                }

                // Langsung set nilai pembayaran baru menggantikan yang lama
                daftarPenyewa[i].pembayaran = pembayaranBaru;

            } else {
                // Jika belum lunas, lanjutkan pelunasan kekurangan sebelumnya
                double kekurangan = daftarPenyewa[i].hargaSewa - daftarPenyewa[i].pembayaran;
                cout << "Kekurangan saat ini        : Rp " << fixed << setprecision(2) << kekurangan << "\n";

                double tambahanBayar;
                cout << "Masukkan jumlah pembayaran tambahan: ";
                if (!(cin >> tambahanBayar) || tambahanBayar < 0) {
                    cout << "Input pembayaran tidak valid atau bernilai minus!\n";
                    break;
                }

                daftarPenyewa[i].pembayaran += tambahanBayar;
            }

            // Validasi ketat pembayaran (harus pas)
            if (daftarPenyewa[i].pembayaran == daftarPenyewa[i].hargaSewa) {
                daftarPenyewa[i].status = "LUNAS";
                cout << "Pembayaran berhasil! Total pas. Status saat ini: LUNAS\n";
            } else if (daftarPenyewa[i].pembayaran < daftarPenyewa[i].hargaSewa) {
                daftarPenyewa[i].status = "BELUM LUNAS";
                double sisaKurang = daftarPenyewa[i].hargaSewa - daftarPenyewa[i].pembayaran;
                cout << "Pembayaran tidak valid! (Kurang Rp " << fixed << setprecision(2) << sisaKurang << ")\n";
                cout << "Status: BELUM LUNAS\n";
            } else {
                daftarPenyewa[i].status = "BELUM LUNAS";
                double kelebihan = daftarPenyewa[i].pembayaran - daftarPenyewa[i].hargaSewa;
                cout << "Pembayaran tidak valid! (Kelebihan Rp " << fixed << setprecision(2) << kelebihan << ")\n";
                cout << "Status: BELUM LUNAS (Pembayaran harus pas)\n";
            }
            break;
        }
    }

    if (!ditemukan) {
        cout << "Data penyewa tidak ditemukan.\n";
    }
}