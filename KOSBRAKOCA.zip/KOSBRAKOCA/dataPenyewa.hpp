#ifndef DATAPENYEWA_HPP
#define DATAPENYEWA_HPP

#include <string>

const int MAX_PENYEWA = 20;

struct Penyewa {
    std::string nama;
    int nomorKamar;
    double hargaSewa;
    double pembayaran;
    std::string status;
};

void tampilkanMenu();
void tambahData(Penyewa daftarPenyewa[], int &jumlahData);
void tampilkanData(Penyewa daftarPenyewa[], int jumlahData);
void cariData(Penyewa daftarPenyewa[], int jumlahData);
void prosesPembayaran(Penyewa daftarPenyewa[], int jumlahData);

#endif